#!/usr/bin/env python3
"""
hdfmonkey_gui.py - a simple graphical front end for hdfmonkey.py

Browse HDF / raw disk images (FAT12/16/32) used by ZX Spectrum emulators,
ESXDOS and ResiDOS: add files and folders, extract them, make folders,
delete, and create / format / clone / rebuild images.

Python GUI by SM7I Projects 2026

Needs only Python 3.8+ (tkinter ships with the Windows installer) and
    pip install pyfatfs
Keep hdfmonkey.py in the same folder.   Run:  python hdfmonkey_gui.py
GPLv3, like the original hdfmonkey by Matt Westcott.
"""
import os
import posixpath
import queue
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import hdfmonkey as hm  # noqa: E402

APP_NAME = "HDF Monkey"


def fmt_size(n):
    if n < 1024:
        return "%d B" % n
    if n < 1 << 20:
        return "%.1f KB" % (n / 1024)
    return "%.1f MB" % (n / (1 << 20))


def remove_tree(fat, path):
    """Delete a directory and everything below it."""
    directory = fat.fs.root_dir.get_entry(path)
    for child in hm.dir_entries(directory):
        child_path = posixpath.join(path, hm._canonical_name(child))
        if child.is_directory():
            remove_tree(fat, child_path)
        else:
            fat.remove(child_path)
    fat.removedir(path)


class ImageOptions(tk.Toplevel):
    """Small modal form: file name / size / FAT type / label (as needed)."""

    def __init__(self, parent, title, ask_file=False, ask_size=False,
                 ask_fat=True, ask_label=True, warning=None):
        super().__init__(parent)
        self.title(title)
        self.transient(parent)
        self.resizable(False, False)
        self.result = None
        frame = ttk.Frame(self, padding=12)
        frame.grid(sticky="nsew")
        row = 0
        self.v_file = tk.StringVar()
        self.v_size = tk.StringVar(value="64M")
        self.v_fat = tk.StringVar(value="Auto")
        self.v_label = tk.StringVar(value="")
        if warning:
            ttk.Label(frame, text=warning, foreground="#a00",
                      wraplength=320).grid(row=row, column=0, columnspan=3,
                                           sticky="w", pady=(0, 8))
            row += 1
        if ask_file:
            ttk.Label(frame, text="Image file:").grid(row=row, column=0, sticky="w")
            ttk.Entry(frame, textvariable=self.v_file, width=34).grid(row=row, column=1, pady=2)
            ttk.Button(frame, text="Browse…", command=self._browse).grid(row=row, column=2, padx=(4, 0))
            row += 1
        if ask_size:
            ttk.Label(frame, text="Size:").grid(row=row, column=0, sticky="w")
            ttk.Entry(frame, textvariable=self.v_size, width=12).grid(row=row, column=1, sticky="w", pady=2)
            ttk.Label(frame, text="e.g. 64M, 1.5G, 512K").grid(row=row, column=2, sticky="w")
            row += 1
        if ask_fat:
            ttk.Label(frame, text="FAT type:").grid(row=row, column=0, sticky="w")
            ttk.Combobox(frame, textvariable=self.v_fat, state="readonly", width=10,
                         values=("Auto", "FAT12", "FAT16", "FAT32")).grid(row=row, column=1, sticky="w", pady=2)
            row += 1
        if ask_fat and ask_size:
            ttk.Label(frame, text="Tip: ESXDOS / NextZXOS need FAT16 or FAT32 (not FAT12).",
                      foreground="#555").grid(row=row, column=0, columnspan=3, sticky="w")
            row += 1
        if ask_label:
            ttk.Label(frame, text="Volume label:").grid(row=row, column=0, sticky="w")
            ttk.Entry(frame, textvariable=self.v_label, width=16).grid(row=row, column=1, sticky="w", pady=2)
            row += 1
        buttons = ttk.Frame(frame)
        buttons.grid(row=row, column=0, columnspan=3, sticky="e", pady=(10, 0))
        ttk.Button(buttons, text="OK", command=self._ok).pack(side="left", padx=4)
        ttk.Button(buttons, text="Cancel", command=self.destroy).pack(side="left")
        self.ask_file, self.ask_size = ask_file, ask_size
        self.bind("<Return>", lambda e: self._ok())
        self.bind("<Escape>", lambda e: self.destroy())
        self.grab_set()
        self.wait_visibility()
        self.focus_set()

    def _browse(self):
        name = filedialog.asksaveasfilename(
            parent=self, defaultextension=".hdf",
            filetypes=[("HDF images", "*.hdf"), ("Raw images", "*.img *.raw"), ("All files", "*.*")])
        if name:
            self.v_file.set(name)

    def _ok(self):
        if self.ask_file and not self.v_file.get().strip():
            messagebox.showerror(APP_NAME, "Please choose a file name.", parent=self)
            return
        sectors = None
        if self.ask_size:
            try:
                sectors = hm.parse_size(self.v_size.get().strip())
                if sectors < hm.MIN_SECTORS:
                    raise hm.HdfError("Size is too small.")
            except hm.HdfError as e:
                messagebox.showerror(APP_NAME, str(e), parent=self)
                return
        fat = {"Auto": None, "FAT12": 12, "FAT16": 16, "FAT32": 32}[self.v_fat.get()]
        self.result = {"file": self.v_file.get().strip(), "sectors": sectors,
                       "fat": fat, "label": self.v_label.get().strip() or None}
        self.destroy()

    @classmethod
    def ask(cls, parent, *args, **kwargs):
        dlg = cls(parent, *args, **kwargs)
        parent.wait_window(dlg)
        return dlg.result


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("760x480")
        self.minsize(560, 320)
        self.image = None      # path of the open image
        self.cwd = "/"
        self.busy = False
        self._build_ui()
        self._update_state()

    # ------------------------------------------------------------ layout --
    def _build_ui(self):
        menubar = tk.Menu(self)
        m_image = tk.Menu(menubar, tearoff=False)
        m_image.add_command(label="Open image…", accelerator="Ctrl+O", command=self.cmd_open)
        m_image.add_command(label="New image…", accelerator="Ctrl+N", command=self.cmd_new)
        m_image.add_separator()
        m_image.add_command(label="Format image…", command=self.cmd_format)
        m_image.add_command(label="Clone image…", command=self.cmd_clone)
        m_image.add_command(label="Rebuild (defragment) image…", command=self.cmd_rebuild)
        m_image.add_separator()
        m_image.add_command(label="Exit", command=self.destroy)
        menubar.add_cascade(label="Image", menu=m_image)
        m_help = tk.Menu(menubar, tearoff=False)
        m_help.add_command(label="About", command=self.cmd_about)
        menubar.add_cascade(label="Help", menu=m_help)
        self.config(menu=menubar)
        self.m_image = m_image

        bar = ttk.Frame(self, padding=(6, 6, 6, 2))
        bar.pack(fill="x")
        self.buttons = {}
        for key, text, cmd in (("open", "Open…", self.cmd_open), ("new", "New…", self.cmd_new),
                               ("add", "Add files…", self.cmd_add_files),
                               ("addf", "Add folder…", self.cmd_add_folder),
                               ("get", "Extract…", self.cmd_extract),
                               ("mkdir", "New folder…", self.cmd_mkdir),
                               ("rm", "Delete", self.cmd_delete),
                               ("refresh", "Refresh", self.refresh)):
            b = ttk.Button(bar, text=text, command=cmd)
            b.pack(side="left", padx=2)
            self.buttons[key] = b

        nav = ttk.Frame(self, padding=(6, 2))
        nav.pack(fill="x")
        self.b_up = ttk.Button(nav, text="Up", width=7, command=self.go_up)
        self.b_up.pack(side="left")
        self.v_path = tk.StringVar(value="/")
        ttk.Label(nav, textvariable=self.v_path, relief="sunken", anchor="w",
                  padding=(6, 2)).pack(side="left", fill="x", expand=True, padx=6)

        body = ttk.Frame(self, padding=(6, 2))
        body.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(body, columns=("size",), selectmode="extended")
        self.tree.heading("#0", text="Name", anchor="w")
        self.tree.heading("size", text="Size", anchor="e")
        self.tree.column("#0", width=480, anchor="w")
        self.tree.column("size", width=100, anchor="e", stretch=False)
        scroll = ttk.Scrollbar(body, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="left", fill="y")
        self.tree.bind("<Double-1>", self._on_double)
        self.tree.bind("<Return>", self._on_double)
        self.tree.bind("<BackSpace>", lambda e: self.go_up())
        self.tree.bind("<Delete>", lambda e: self.cmd_delete())
        self.tree.bind("<<TreeviewSelect>>", lambda e: self._update_state())

        self.ctx = tk.Menu(self, tearoff=False)
        self.ctx.add_command(label="Extract…", command=self.cmd_extract)
        self.ctx.add_command(label="Delete", command=self.cmd_delete)
        self.tree.bind("<Button-3>", self._on_context)

        status = ttk.Frame(self, padding=(6, 2))
        status.pack(fill="x")
        self.v_status = tk.StringVar(value="No image open. Use Open… or New…")
        ttk.Label(status, textvariable=self.v_status).pack(side="left")
        self.progress = ttk.Progressbar(status, mode="indeterminate", length=120)

        self.bind("<Control-o>", lambda e: self.cmd_open())
        self.bind("<Control-n>", lambda e: self.cmd_new())
        self.bind("<F5>", lambda e: self.refresh())

    def _update_state(self):
        has = self.image is not None and not self.busy
        sel = bool(self.tree.selection())
        for key in ("add", "addf", "mkdir", "refresh"):
            self.buttons[key].state(["!disabled"] if has else ["disabled"])
        for key in ("get", "rm"):
            self.buttons[key].state(["!disabled"] if has and sel else ["disabled"])
        for key in ("open", "new"):
            self.buttons[key].state(["!disabled"] if not self.busy else ["disabled"])
        self.b_up.state(["!disabled"] if has and self.cwd != "/" else ["disabled"])
        for label in ("Format image…", "Clone image…", "Rebuild (defragment) image…"):
            self.m_image.entryconfig(label, state="normal" if has else "disabled")

    # ------------------------------------------------- background worker --
    def run_bg(self, work, done=None, message="Working…"):
        if self.busy:
            return
        self.busy = True
        self.v_status.set(message)
        self.progress.pack(side="right")
        self.progress.start(12)
        self.config(cursor="watch")
        self._update_state()
        results = queue.Queue()

        def target():
            try:
                results.put((True, work()))
            except hm.HdfError as e:
                results.put((False, str(e)))
            except Exception as e:  # keep the GUI alive whatever happens
                results.put((False, "%s: %s" % (type(e).__name__, e)))

        threading.Thread(target=target, daemon=True).start()
        self._poll(results, done)

    def _poll(self, results, done):
        try:
            ok, value = results.get_nowait()
        except queue.Empty:
            self.after(80, self._poll, results, done)
            return
        self.busy = False
        self.progress.stop()
        self.progress.pack_forget()
        self.config(cursor="")
        if not ok:
            messagebox.showerror(APP_NAME, value, parent=self)
        if ok and done:
            done(value)
        elif self.image:
            self.refresh()
        self._update_state()

    # -------------------------------------------------------- browsing --
    def _open_fat(self, writable):
        return hm.open_fat(self.image, writable)

    def refresh(self):
        if not self.image or self.busy:
            return
        image, cwd = self.image, self.cwd

        def work():
            fat = hm.open_fat(image, False)
            try:
                entries = hm.list_dir(fat, cwd)
            finally:
                fat.close()
            return entries

        self.run_bg(work, self._show, "Reading…")

    def _show(self, entries):
        self.tree.delete(*self.tree.get_children())
        ordered = sorted(entries, key=lambda e: (not e[1], e[0].lower()))
        for name, is_dir, size in ordered:
            self.tree.insert("", "end", iid=name, text=("▸ " if is_dir else "    ") + name,
                             values=("<DIR>" if is_dir else fmt_size(size),),
                             tags=("dir",) if is_dir else ())
        self.v_path.set(self.cwd)
        folders = sum(1 for e in entries if e[1])
        try:
            info = hm.image_info(self.image)
        except Exception:
            info = ""
        self.v_status.set("%d files, %d folders   |   %s" % (len(entries) - folders, folders, info))
        self.title("%s - %s" % (os.path.basename(self.image), APP_NAME))
        self._update_state()

    def _selected_names(self):
        return list(self.tree.selection())  # iid == real name

    def _is_dir(self, name):
        return "dir" in self.tree.item(name, "tags")

    def _on_double(self, _event=None):
        sel = self.tree.selection()
        if len(sel) == 1 and self._is_dir(sel[0]):
            self.cwd = posixpath.join(self.cwd, sel[0])
            self.refresh()

    def go_up(self):
        if self.image and self.cwd != "/":
            self.cwd = posixpath.dirname(self.cwd.rstrip("/")) or "/"
            self.refresh()

    def _on_context(self, event):
        row = self.tree.identify_row(event.y)
        if row:
            if row not in self.tree.selection():
                self.tree.selection_set(row)
            self.ctx.tk_popup(event.x_root, event.y_root)

    # ----------------------------------------------------------- images --
    def open_image(self, path):
        def work():
            return hm.image_info(path)  # validates that a FAT filesystem is there

        def done(_info):
            self.image, self.cwd = path, "/"
            self.refresh()

        self.run_bg(work, done, "Opening…")

    def cmd_open(self):
        path = filedialog.askopenfilename(
            parent=self, filetypes=[("Disk images", "*.hdf *.img *.raw"), ("All files", "*.*")])
        if path:
            self.open_image(path)

    def cmd_new(self):
        opts = ImageOptions.ask(self, "New image", ask_file=True, ask_size=True)
        if not opts:
            return
        path = opts["file"]
        if os.path.exists(path) and not messagebox.askyesno(
                APP_NAME, "%s already exists. Overwrite it?" % path, parent=self):
            return

        def work():
            img = hm.DiskImage.create(path, opts["sectors"])
            try:
                hm.make_filesystem(img, opts["fat"], opts["label"])
            finally:
                img.close()
            return path

        self.run_bg(work, self.open_image, "Creating image…")

    def cmd_format(self):
        opts = ImageOptions.ask(self, "Format image", warning="Formatting erases EVERYTHING in %s." % os.path.basename(self.image))
        if not opts:
            return
        image = self.image

        def work():
            img = hm.DiskImage(image, writable=True)
            try:
                hm.make_filesystem(img, opts["fat"], opts["label"])
            finally:
                img.close()
            return image

        def done(_):
            self.cwd = "/"
            self.refresh()

        self.run_bg(work, done, "Formatting…")

    def cmd_clone(self):
        dest = filedialog.asksaveasfilename(
            parent=self, title="Clone to…", defaultextension=".hdf",
            filetypes=[("HDF images", "*.hdf"), ("Raw images", "*.img *.raw")])
        if not dest:
            return
        src = self.image
        self.run_bg(lambda: hm.cmd_clone([src, dest], 0),
                    lambda _: self.v_status.set("Cloned to %s" % dest), "Cloning…")

    def cmd_rebuild(self):
        dest = filedialog.asksaveasfilename(
            parent=self, title="Rebuild into…", defaultextension=".hdf",
            filetypes=[("HDF images", "*.hdf"), ("Raw images", "*.img *.raw")])
        if not dest:
            return
        if os.path.abspath(dest) == os.path.abspath(self.image):
            messagebox.showerror(APP_NAME, "Choose a different file for the rebuilt copy.", parent=self)
            return
        opts = ImageOptions.ask(self, "Rebuild image")
        if not opts:
            return
        args = ([] if opts["fat"] is None else ["--fat%d" % opts["fat"]]) + [self.image, dest]
        if opts["label"]:
            args.append(opts["label"])
        self.run_bg(lambda: hm.cmd_rebuild(args, 0),
                    lambda _: self.v_status.set("Rebuilt into %s" % dest), "Rebuilding…")

    # ------------------------------------------------------- file ops --
    def add_paths(self, paths):
        image, cwd = self.image, self.cwd

        def work():
            errors = []
            fat = hm.open_fat(image, True)
            try:
                for src in paths:
                    name = os.path.basename(src.rstrip("/\\")) or src
                    hm.fat_copy_in(fat, src, posixpath.join(cwd, name), errors)
            finally:
                fat.close()
            return errors

        def done(errors):
            self.refresh()
            if errors:
                messagebox.showwarning(APP_NAME, "Some items could not be added:\n\n" +
                                       "\n".join(errors[:10]), parent=self)

        self.run_bg(work, done, "Copying into image…")

    def cmd_add_files(self):
        paths = filedialog.askopenfilenames(parent=self, title="Add files")
        if paths:
            self.add_paths(list(paths))

    def cmd_add_folder(self):
        path = filedialog.askdirectory(parent=self, title="Add folder")
        if path:
            self.add_paths([path])

    def extract_to(self, folder, names):
        image, cwd = self.image, self.cwd

        def work():
            errors = []
            fat = hm.open_fat(image, False)
            try:
                for name in names:
                    hm.fat_copy_out(fat, posixpath.join(cwd, name), folder, errors)
            finally:
                fat.close()
            return errors

        def done(errors):
            self.v_status.set("Extracted %d item(s) to %s" % (len(names), folder))
            if errors:
                messagebox.showwarning(APP_NAME, "\n".join(errors[:10]), parent=self)

        self.run_bg(work, done, "Extracting…")

    def cmd_extract(self):
        names = self._selected_names()
        if not names:
            return
        folder = filedialog.askdirectory(parent=self, title="Extract to folder")
        if folder:
            self.extract_to(folder, names)

    def make_folder(self, name):
        image, path = self.image, posixpath.join(self.cwd, name)

        def work():
            fat = hm.open_fat(image, True)
            try:
                try:
                    fat.makedir(hm.resolve(fat, path))
                except Exception as e:
                    raise hm.HdfError(hm.fat_error("Directory creation failed", e))
            finally:
                fat.close()

        self.run_bg(work, lambda _: self.refresh(), "Creating folder…")

    def cmd_mkdir(self):
        name = simpledialog.askstring(APP_NAME, "New folder name:", parent=self)
        if name and name.strip():
            self.make_folder(name.strip())

    def delete_names(self, names):
        image, cwd = self.image, self.cwd

        def work():
            fat = hm.open_fat(image, True)
            try:
                for name in names:
                    path = hm.resolve(fat, posixpath.join(cwd, name))
                    if fat.isdir(path):
                        remove_tree(fat, path)
                    else:
                        fat.remove(path)
            except Exception as e:
                raise hm.HdfError(hm.fat_error("Deletion failed", e))
            finally:
                fat.close()

        self.run_bg(work, lambda _: self.refresh(), "Deleting…")

    def cmd_delete(self):
        names = self._selected_names()
        if not names or self.busy:
            return
        what = names[0] if len(names) == 1 else "%d items" % len(names)
        if messagebox.askyesno(APP_NAME, "Delete %s from the image?\n(Folders are deleted with all their contents.)" % what,
                               icon="warning", parent=self):
            self.delete_names(names)

    def cmd_about(self):
        messagebox.showinfo(APP_NAME, "HDF Monkey - a Python/Tk port of hdfmonkey\n"
                            "Original by Matt Westcott (github.com/gasman/hdfmonkey)\n"
                            "FAT access via pyfatfs. GPLv3.", parent=self)


def main():
    if sys.platform == "win32":
        try:  # crisp text on high-DPI displays
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    app = App()
    if len(sys.argv) > 1 and os.path.isfile(sys.argv[1]):  # also lets you drop an .hdf on the script
        app.after(100, app.open_image, sys.argv[1])
    app.mainloop()


if __name__ == "__main__":
    main()
