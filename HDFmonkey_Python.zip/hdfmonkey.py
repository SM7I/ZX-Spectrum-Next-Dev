#!/usr/bin/env python3
"""
hdfmonkey.py - a Python port of hdfmonkey, the Swiss Army Knife for working
with FAT filesystems inside HDF (RS-IDE) and raw disk images, as used by ZX
Spectrum / ZX Spectrum Next emulators and ESXDOS / ResiDOS.

Original C tool: https://github.com/gasman/hdfmonkey  (c) Matt Westcott, GPLv3
This port follows the original's command line and on-disk behaviour, and is
therefore also released under GPLv3.

Python port by SM7I Projects 2026

Commands:
    clone    <oldimage> <newimage>
    create   [--fat12|--fat16|--fat32] <image> <size> [label]
    format   [--fat12|--fat16|--fat32] <image> [label]
    get      <image> <sourcefile> [destfile]
    ls       <image> [path]
    mkdir    <image> <dirname>
    put      <image> <source-files...> <dest-file-or-dir>
    rebuild  [--fat12|--fat16|--fat32] <src-image> <dest-image> [label]
    rm       <image> <filename>

Works on Windows, Linux and macOS (Python 3.8+).  A simple graphical front end
is in hdfmonkey_gui.py (it needs this file next to it).

Requires:  pip install pyfatfs
Extra (not in the C version):  -p N / --partition N  selects MBR partition
entry N (0-3) instead of the first one.  It can be given before the command.
"""

import glob
import os
import posixpath
import shutil
import struct
import sys
import time
import warnings

try:
    from pyfatfs.PyFatFS import PyFatFS
    from pyfatfs._exceptions import PyFATException
    import fs.errors as fserrors
except ImportError:  # pragma: no cover
    sys.exit("hdfmonkey.py needs the 'pyfatfs' package:  pip install pyfatfs")

warnings.filterwarnings("ignore")  # pyfatfs warns about dirty flags etc.

# --------------------------------------------------------------------------
# HDF container handling (port of image_file.c)
# --------------------------------------------------------------------------

HDF_SIGNATURE = b"RS-IDE\x1a"
HDF_PREAMBLE = b"RS-IDE\x1a\x11\x00\x16\x02"  # v1.1, not halved, offset 0x216
HDF_HEADER_SIZE = 0x0216
HDF_MODEL_NUMBER = b"rCaeet dybh fdomknye                    "  # "Created by hdfmonkey"
SECTOR = 512
MIN_SECTORS = 128
COPY_CHUNK = 1 << 20


class HdfError(Exception):
    """A user-facing error (printed without a traceback)."""


def filename_is_hdf(name):
    return name[-3:].lower() == "hdf"


def image_file_is_hdf(path):
    try:
        with open(path, "rb") as f:
            return f.read(len(HDF_SIGNATURE)) == HDF_SIGNATURE
    except OSError as e:
        raise HdfError("open() error: %s" % e.strerror)


def hdf_header(sector_count):
    """Build the 0x216-byte HDF header (RS-IDE 1.1 + ATA IDENTIFY block)."""
    header = bytearray(HDF_HEADER_SIZE)
    header[:len(HDF_PREAMBLE)] = HDF_PREAMBLE
    ident = 0x16

    if sector_count >= 16383 * 16 * 63:  # > 8GB: dummy 'large disk' geometry
        cyls, heads, spt = 16383, 16, 63
    else:
        heads = 16
        while heads > 1 and sector_count % heads:
            heads -= 1
        per_head = sector_count // heads
        spt = 63
        while spt > 1 and per_head % spt:
            spt -= 1
        cyls = per_head // spt
        if cyls > 16384:
            cyls, heads, spt = 16383, 16, 63

    struct.pack_into("<H", header, ident + 2, cyls & 0xFFFF)   # word 1
    header[ident + 6] = heads & 0xFF                           # word 3
    header[ident + 12] = spt & 0xFF                            # word 6
    header[ident + 54:ident + 94] = HDF_MODEL_NUMBER           # words 27-46
    header[ident + 99] = 0x02                                  # word 49: LBA
    struct.pack_into("<I", header, ident + 120, sector_count & 0xFFFFFFFF)
    return bytes(header)


class DiskImage:
    """A raw or HDF disk image; addresses are relative to the first sector."""

    def __init__(self, path, writable=False):
        self.path = path
        self.writable = writable
        try:
            self.f = open(path, "r+b" if writable else "rb")
        except OSError as e:
            raise HdfError("open() error: %s" % e.strerror)
        self.is_hdf = image_file_is_hdf(path)
        self.data_offset = 0
        self.bytes_per_sector = SECTOR
        if self.is_hdf:
            hdr = self.f.read(11)
            if len(hdr) != 11:
                raise HdfError("Error reading HDF header")
            self.data_offset = hdr[0x09] | (hdr[0x0A] << 8)
            if hdr[0x08] & 0x01:
                self.bytes_per_sector = 256  # 'halved' sector data
        size = os.fstat(self.f.fileno()).st_size
        self.sector_count = (size - self.data_offset) // self.bytes_per_sector

    @classmethod
    def create(cls, path, sector_count):
        """Create a new, zero-filled image (HDF if the name ends in .hdf)."""
        try:
            with open(path, "wb") as f:
                if filename_is_hdf(path):
                    f.write(hdf_header(sector_count))
                    f.truncate(sector_count * SECTOR + HDF_HEADER_SIZE)
                else:
                    f.truncate(sector_count * SECTOR)
        except OSError as e:
            raise HdfError("Could not create image: %s" % e.strerror)
        return cls(path, writable=True)

    def read(self, pos, count):
        self.f.seek(pos + self.data_offset)
        data = self.f.read(count)
        if len(data) != count:
            raise HdfError("read() error: unexpected end of image")
        return data

    def write(self, pos, data):
        self.f.seek(pos + self.data_offset)
        self.f.write(data)

    def close(self):
        self.f.close()

    # -- FAT location (the same search FatFs does when it mounts) ----------
    def require_standard_sectors(self):
        if self.bytes_per_sector != SECTOR:
            raise HdfError("HDF images with halved (256 byte) sectors are "
                           "not supported")

    @staticmethod
    def _boot_sector_kind(sector):
        """0: FAT boot record, 1: valid boot sector but not FAT, 2: other"""
        if sector[510:512] != b"\x55\xaa":
            return 2
        if sector[54:57] == b"FAT" or sector[82:85] == b"FAT":
            return 0
        return 1

    def fat_start_sector(self, partition=0):
        """LBA of the FAT boot record: sector 0 (no MBR) or a partition."""
        self.require_standard_sectors()
        sector0 = self.read(0, SECTOR)
        kind = self._boot_sector_kind(sector0)
        if kind == 0:
            return 0
        if kind == 1:
            entry = sector0[0x1BE + partition * 16:0x1BE + partition * 16 + 16]
            if entry[4]:
                start = struct.unpack_from("<I", entry, 8)[0]
                if self._boot_sector_kind(self.read(start * SECTOR, SECTOR)) == 0:
                    return start
        raise HdfError("mount failed: No FAT filesystem found")

    def fat_offset(self, partition=0):
        """Byte offset of the filesystem from the start of the *file*."""
        return self.data_offset + self.fat_start_sector(partition) * SECTOR


# --------------------------------------------------------------------------
# Formatter (port of f_mkfs, FDISK layout: MBR + one partition at LBA 63)
# --------------------------------------------------------------------------

N_FATS = 2
N_ROOTDIR = 512
_SSTBL = (2048000, 1024000, 512000, 256000, 128000, 64000, 32000, 16000,
          8000, 4000, 0)
_CSTBL = (32768, 16384, 8192, 4096, 2048, 16384, 8192, 4096, 2048, 1024, 512)


def make_filesystem(img, fmt=None, label=None):
    """Write an MBR and a FAT12/16/32 filesystem over the whole image."""
    img.require_standard_sectors()
    total = img.sector_count
    if total < MIN_SECTORS:
        raise HdfError("Formatting failed: Disk is unsuitable for formatting")

    b_part = 63
    n_part = total - b_part
    d = n_part
    n = 0
    while d < _SSTBL[n]:
        n += 1
    default_spc = _CSTBL[n] // SECTOR               # FatFs' size-based default

    def geometry(fmt, spc):
        n_clst = n_part // spc
        if fmt == 12:
            n_fat = ((n_clst * 3 + 1) // 2 + 3 + SECTOR - 1) // SECTOR
            n_rsv, n_dir = 1, N_ROOTDIR * 32 // SECTOR
        elif fmt == 16:
            n_fat = (n_clst * 2 + 4 + SECTOR - 1) // SECTOR
            n_rsv, n_dir = 1, N_ROOTDIR * 32 // SECTOR
        else:
            n_fat = (n_clst * 4 + 8 + SECTOR - 1) // SECTOR
            n_rsv, n_dir = 33, 0
        n_clst = (n_part - n_rsv - n_fat * N_FATS - n_dir) // spc
        return n_fat, n_rsv, n_dir, n_clst

    def valid(fmt, n_clst):  # the cluster count *defines* the FAT type
        return {12: 1 <= n_clst < 4085, 16: 4085 <= n_clst < 65525,
                32: n_clst >= 65525}[fmt]

    if fmt is None:                                 # same rule as f_mkfs
        n_clst = n_part // default_spc
        fmt = 12
        if n_clst >= 0xFF5:
            fmt = 16
        if n_clst >= 0xFFF5:
            fmt = 32

    # Use FatFs' cluster size when it gives a valid volume; otherwise (e.g. a
    # forced --fat32 on a small image, which the C tool would silently turn
    # into a corrupt volume) look for a cluster size that does.
    spc = None
    for cand in [default_spc] + sorted((1, 2, 4, 8, 16, 32, 64),
                                       key=lambda c: abs(c - default_spc)):
        if valid(fmt, geometry(fmt, cand)[3]):
            spc = cand
            break
    if spc is None:
        raise HdfError("Formatting failed: image size is unsuitable for FAT%d"
                       % fmt)
    n_fat, n_rsv, n_dir, n_clst = geometry(fmt, spc)

    # ---- partition table -------------------------------------------------
    mbr = bytearray(SECTOR)
    entry = bytearray(16)
    struct.pack_into("<I", entry, 0, 0x00010180)           # status + CHS start
    n_disk = b_part + n_part
    if n_disk < 63 * 255 * 1024:
        cyl = n_disk // 63 // 255
        entry[7] = cyl & 0xFF
        entry[6] = ((cyl >> 2) | 63) & 0xFF
    else:
        entry[6:8] = b"\xff\xff"
    entry[5] = 254
    if fmt != 32:
        entry[4] = 0x04 if n_part < 0x10000 else 0x06
    else:
        entry[4] = 0x0C
    struct.pack_into("<II", entry, 8, b_part, n_part)
    mbr[0x1BE:0x1CE] = entry
    mbr[510:512] = b"\x55\xaa"
    img.write(0, bytes(mbr))
    media = 0xF8

    # ---- boot record -----------------------------------------------------
    vol_id = int(time.time()) & 0xFFFFFFFF
    lab = (label or "NO NAME").encode("ascii", "replace")[:11].ljust(11)
    bs = bytearray(SECTOR)
    bs[0:3] = b"\xeb\xfe\x90"
    struct.pack_into("<HBHBH", bs, 11, SECTOR, spc, n_rsv, N_FATS,
                     N_ROOTDIR if fmt != 32 else 0)
    if n_part < 0x10000:
        struct.pack_into("<H", bs, 19, n_part)
    else:
        struct.pack_into("<I", bs, 32, n_part)
    bs[21] = media
    struct.pack_into("<HHI", bs, 24, 63, 255, b_part)      # SecPerTrk, Heads, Hidden
    if fmt != 32:
        struct.pack_into("<H", bs, 22, n_fat)
        bs[36] = 0x80
        bs[38] = 0x29
        struct.pack_into("<I", bs, 39, vol_id)
        bs[43:54] = lab
        bs[54:62] = (b"FAT12   " if fmt == 12 else b"FAT16   ")
    else:
        struct.pack_into("<I", bs, 36, n_fat)
        struct.pack_into("<I", bs, 44, 2)                  # root cluster
        struct.pack_into("<HH", bs, 48, 1, 6)              # FSInfo, backup boot
        bs[64] = 0x80
        bs[66] = 0x29
        struct.pack_into("<I", bs, 67, vol_id)
        bs[71:82] = lab
        bs[82:90] = b"FAT32   "
    bs[510:512] = b"\x55\xaa"
    base = b_part * SECTOR
    img.write(base, bytes(bs))
    if fmt == 32:
        img.write(base + 6 * SECTOR, bytes(bs))

    # ---- FAT area + root directory --------------------------------------
    zero = bytes(SECTOR)
    pos = base + n_rsv * SECTOR
    for _ in range(N_FATS):
        first = bytearray(SECTOR)
        if fmt != 32:
            val = (0x00FFFF00 if fmt == 12 else 0xFFFFFF00) | media
            struct.pack_into("<I", first, 0, val)
        else:
            struct.pack_into("<III", first, 0, 0xFFFFFFF8, 0xFFFFFFFF,
                             0x0FFFFFFF)
        img.write(pos, bytes(first))
        pos += SECTOR
        _write_zeros(img, pos, (n_fat - 1) * SECTOR)
        pos += (n_fat - 1) * SECTOR
    _write_zeros(img, pos, (spc if fmt == 32 else n_dir) * SECTOR)

    if fmt == 32:
        fsi = bytearray(SECTOR)
        struct.pack_into("<I", fsi, 0, 0x41615252)
        struct.pack_into("<I", fsi, 484, 0x61417272)
        struct.pack_into("<II", fsi, 488, n_clst - 1, 0xFFFFFFFF)
        fsi[510:512] = b"\x55\xaa"
        img.write(base + 1 * SECTOR, bytes(fsi))
        img.write(base + 7 * SECTOR, bytes(fsi))
    img.f.flush()


def _write_zeros(img, pos, length):
    img.f.seek(pos + img.data_offset)
    chunk = bytes(min(length, COPY_CHUNK)) if length else b""
    while length > 0:
        n = min(length, len(chunk))
        img.f.write(chunk[:n])
        length -= n


# --------------------------------------------------------------------------
# FAT access helpers
# --------------------------------------------------------------------------

def open_fat(path, writable, partition=0):
    """Open the FAT filesystem inside an image; returns (DiskImage, PyFatFS)."""
    img = DiskImage(path, writable)
    try:
        offset = img.fat_offset(partition)
    finally:
        img.close()  # PyFatFS opens its own handle
    try:
        fat = PyFatFS(path, offset=offset, read_only=not writable)
    except (PyFATException, OSError) as e:
        raise HdfError("mount failed: %s" % e)
    return fat


def norm(path):
    """Normalise a FAT path: '/'-separated, absolute, no trailing slash."""
    path = path.replace("\\", "/")
    path = posixpath.normpath("/" + path)
    return path


def _canonical_name(entry):
    """The name pyfatfs itself matches on (LFN if present, else 8.3)."""
    try:
        return entry.get_long_name()
    except Exception:
        return entry.get_short_name()


def display_name(entry):
    """Name as FatFs shows it: LFN, else 8.3 honouring the NT lower-case flags."""
    try:
        return entry.get_long_name()
    except Exception:
        pass
    base, dot, ext = entry.get_short_name().partition(".")
    if entry.ntres & 0x08:
        base = base.lower()
    if entry.ntres & 0x10:
        ext = ext.lower()
    return base + dot + ext


def dir_entries(directory):
    """Real entries (no '.', '..' or volume label) in on-disk order."""
    return [e for e in directory._get_entries_raw()
            if not (e.is_special() or e.is_volume_id())]


def resolve(fat, path):
    """Make FAT's case-insensitive lookup work on top of pyfatfs: map each
    existing component of *path* to the exact name pyfatfs knows, and leave
    the rest (e.g. a file about to be created) as typed."""
    parts = [p for p in norm(path).split("/") if p]
    out, cur = [], fat.fs.root_dir
    for i, part in enumerate(parts):
        match = None
        if cur is not None and cur.is_directory():
            low = part.casefold()
            for e in dir_entries(cur):
                names = {e.get_short_name().casefold(), display_name(e).casefold()}
                try:
                    names.add(e.get_long_name().casefold())
                except Exception:
                    pass
                if low in names:
                    match = e
                    break
        if match is None:
            out.extend(parts[i:])
            break
        out.append(_canonical_name(match))
        cur = match
    return "/" + "/".join(out)


def fat_error(message, exc):
    reasons = [
        (fserrors.ResourceNotFound, "File not found"),
        (fserrors.DirectoryExpected, "Path not found"),
        (fserrors.FileExpected, "Access denied"),
        (fserrors.DirectoryExists, "File / directory already exists"),
        (fserrors.FileExists, "File / directory already exists"),
        (fserrors.DirectoryNotEmpty, "Access denied"),
        (fserrors.InvalidCharsInPath, "File / directory name is invalid"),
        (fserrors.IllegalBackReference, "File / directory name is invalid"),
        (fserrors.ResourceReadOnly, "Drive is write-protected"),
        (fserrors.InsufficientStorage, "Access denied (disk full?)"),
    ]
    for cls, text in reasons:
        if isinstance(exc, cls):
            return "%s: %s" % (message, text)
    return "%s: %s" % (message, exc)


def fat_is_dir(fat, path):
    try:
        return fat.isdir(resolve(fat, path))
    except fserrors.FSError:
        return False


def _report(errors, message):
    if errors is None:
        print(message)
    else:
        errors.append(message)


def fat_copy_in(fat, source, dest, errors=None):
    """put_file(): copy a local file or directory tree into the image.
    Problems are printed, or appended to *errors* if a list is given."""
    ok = True
    dest = resolve(fat, dest)
    if os.path.isdir(source):
        if not fat_is_dir(fat, dest):
            try:
                fat.makedir(dest)
            except (fserrors.FSError, PyFATException) as e:
                _report(errors, fat_error("Directory creation failed", e))
                return False
        for name in os.listdir(source):
            ok &= fat_copy_in(fat, os.path.join(source, name),
                              posixpath.join(dest, name), errors)
        return ok
    try:
        src = open(source, "rb")
    except OSError as e:
        _report(errors, "Could not open file for reading: %s" % e.strerror)
        return False
    try:
        with src, fat.openbin(dest, "w") as out:
            shutil.copyfileobj(src, out, 65536)
    except (fserrors.FSError, PyFATException, OSError) as e:
        _report(errors, fat_error("Error writing file", e))
        return False
    return True


def safe_local_name(name):
    """FAT allows a few characters that Windows does not (and vice versa)."""
    cleaned = "".join("_" if c in '<>:"/\\|?*' or ord(c) < 32 else c
                      for c in name).rstrip(" .")
    return cleaned or "_"


def fat_copy_out(fat, path, local_dir, errors=None):
    """Extract a file or a whole directory tree from the image into
    *local_dir* (which must exist)."""
    path = resolve(fat, path)
    entry = fat.fs.root_dir.get_entry(path)
    target = os.path.join(local_dir, safe_local_name(display_name(entry)
                                                      if path != "/" else "root"))
    ok = True
    if entry.is_directory():
        os.makedirs(target, exist_ok=True)
        for child in dir_entries(entry):
            ok &= fat_copy_out(fat, posixpath.join(path, _canonical_name(child)),
                               target, errors)
        return ok
    try:
        with fat.openbin(path, "r") as src, open(target, "wb") as out:
            shutil.copyfileobj(src, out, 65536)
    except (fserrors.FSError, PyFATException, OSError) as e:
        _report(errors, "Error extracting %s: %s" % (path, e))
        return False
    return True


def list_dir(fat, path="/"):
    """[(name, is_dir, size), ...] in on-disk order; raises HdfError."""
    path = resolve(fat, path)
    try:
        directory = fat.fs.root_dir.get_entry(path)
    except PyFATException:
        raise HdfError("Error opening dir: Path not found")
    if not directory.is_directory():
        raise HdfError("Error opening dir: Path not found")
    return [(display_name(e), e.is_directory(),
             0 if e.is_directory() else e.get_size())
            for e in dir_entries(directory)]


def image_info(path, partition=0):
    """One-line description of an image for display."""
    img = DiskImage(path)
    try:
        kind = "HDF" if img.is_hdf else "raw"
        size = img.sector_count * img.bytes_per_sector
    finally:
        img.close()
    fat = open_fat(path, False, partition)
    try:
        ftype = {fat.fs.FAT_TYPE_FAT12: "FAT12", fat.fs.FAT_TYPE_FAT16: "FAT16",
                 fat.fs.FAT_TYPE_FAT32: "FAT32"}.get(fat.fs.fat_type, "FAT?")
    finally:
        fat.close()
    return "%s image, %.1f MB, %s" % (kind, size / (1 << 20), ftype)


def fat_copy_tree(src_fat, dst_fat, src_dir="/", dst_dir="/"):
    """copy_dir(): recursively copy one FAT filesystem's tree into another."""
    for e in dir_entries(src_fat.fs.root_dir.get_entry(src_dir)):
        s = posixpath.join(src_dir, _canonical_name(e))
        d = posixpath.join(dst_dir, display_name(e))
        if e.is_directory():
            dst_fat.makedir(d)
            fat_copy_tree(src_fat, dst_fat, s, d)
        else:
            with src_fat.openbin(s, "r") as fin, dst_fat.openbin(d, "w") as fout:
                shutil.copyfileobj(fin, fout, 65536)


# --------------------------------------------------------------------------
# Commands
# --------------------------------------------------------------------------

def parse_fat_flags(args):
    """Strip --fat12/16/32 from args; return (fmt, remaining)."""
    fmt, rest = None, []
    for a in args:
        if a in ("--fat12", "--fat16", "--fat32"):
            fmt = int(a[5:])
        else:
            rest.append(a)
    return fmt, rest


def parse_size(text):
    """'64M', '1.5G', '512K', '1000000', '1000B' -> sector count."""
    i = len(text)
    while i > 0 and not (text[i - 1].isdigit() or text[i - 1] == "."):
        i -= 1
    try:
        number = float(text[:i])
    except ValueError:
        raise HdfError("Invalid size: %s" % text)
    unit = text[i:][:1]
    mult = {"G": 1 << 30, "M": 1 << 20, "K": 1 << 10, "B": 1, "": 1}.get(unit.upper())
    if mult is None:
        raise HdfError("Unrecognised size unit specifier: %s" % unit)
    return int(number * mult / SECTOR)


def cmd_clone(args, part):
    if len(args) < 1:
        raise HdfError("No source image filename supplied")
    if len(args) < 2:
        raise HdfError("No destination image filename supplied")
    src = DiskImage(args[0])
    try:
        src.require_standard_sectors()
        dst = DiskImage.create(args[1], src.sector_count)
        try:
            total = src.sector_count * SECTOR
            pos = 0
            while pos < total:
                n = min(COPY_CHUNK, total - pos)
                dst.write(pos, src.read(pos, n))
                pos += n
        finally:
            dst.close()
    finally:
        src.close()


def cmd_create(args, part):
    fmt, args = parse_fat_flags(args)
    if not 2 <= len(args) <= 3:
        raise HdfError("Usage: hdfmonkey create [--fat12|--fat16|--fat32] "
                       "<imagefile> <size> [volumelabel]")
    sectors = parse_size(args[1])
    if sectors < MIN_SECTORS:
        raise HdfError("Formatting failed: Disk is unsuitable for formatting")
    img = DiskImage.create(args[0], sectors)
    try:
        make_filesystem(img, fmt, args[2] if len(args) > 2 else None)
    finally:
        img.close()


def cmd_format(args, part):
    fmt, args = parse_fat_flags(args)
    if not 1 <= len(args) <= 2:
        raise HdfError("Usage: hdfmonkey format [--fat12|--fat16|--fat32] "
                       "<imagefile> [volumelabel]")
    img = DiskImage(args[0], writable=True)
    try:
        make_filesystem(img, fmt, args[1] if len(args) > 1 else None)
    finally:
        img.close()


def cmd_get(args, part):
    if len(args) < 1:
        raise HdfError("No image filename supplied")
    if len(args) < 2:
        raise HdfError("No source filename supplied")
    fat = open_fat(args[0], False, part)
    try:
        try:
            src = fat.openbin(resolve(fat, args[1]), "r")
        except (fserrors.FSError, PyFATException) as e:
            raise HdfError(fat_error("Error opening file", e))
        with src:
            if len(args) > 2:
                try:
                    out = open(args[2], "wb")
                except OSError as e:
                    raise HdfError("Could not open file for writing: %s" % e.strerror)
                with out:
                    shutil.copyfileobj(src, out, 65536)
            else:
                shutil.copyfileobj(src, sys.stdout.buffer, 65536)
                sys.stdout.buffer.flush()
    finally:
        fat.close()


def cmd_put(args, part):
    if len(args) < 3:
        raise HdfError("Usage: hdfmonkey put <image_file> <source_files> "
                       "<destination_file_or_dir>")
    fat = open_fat(args[0], True, part)
    ok = True
    try:
        sources = []
        for pattern in args[1:-1]:
            hits = sorted(glob.glob(pattern)) if glob.has_magic(pattern) else []
            sources.extend(hits or [pattern])  # cmd.exe/PowerShell don't glob
        dest = norm(args[-1].rstrip("/\\") or "/")
        if not fat_is_dir(fat, dest):
            if len(sources) > 1:
                raise HdfError("Destination must be an existing directory "
                               "when copying multiple files")
            ok = fat_copy_in(fat, sources[0], dest)
        else:
            for src in sources:
                name = os.path.basename(src.rstrip("/\\")) or src
                ok &= fat_copy_in(fat, src, posixpath.join(dest, name))
    finally:
        fat.close()
    return 0 if ok else 1


def cmd_ls(args, part):
    if len(args) < 1:
        raise HdfError("No image filename supplied")
    fat = open_fat(args[0], False, part)
    try:
        for name, is_dir, size in list_dir(fat, args[1] if len(args) > 1 else "/"):
            print("[DIR]\t%s" % name if is_dir else "%d\t%s" % (size, name))
    finally:
        fat.close()


def cmd_mkdir(args, part):
    if len(args) < 1:
        raise HdfError("No image filename supplied")
    if len(args) < 2:
        raise HdfError("No directory name supplied")
    fat = open_fat(args[0], True, part)
    try:
        try:
            fat.makedir(resolve(fat, args[1]))
        except (fserrors.FSError, PyFATException) as e:
            # FatFs reports a missing parent as 'Path not found'
            if isinstance(e, fserrors.ResourceNotFound):
                e = fserrors.DirectoryExpected(args[1])
            raise HdfError(fat_error("Directory creation failed", e))
    finally:
        fat.close()


def cmd_rm(args, part):
    if len(args) < 1:
        raise HdfError("No image filename supplied")
    if len(args) < 2:
        raise HdfError("No filename supplied")
    fat = open_fat(args[0], True, part)
    try:
        path = resolve(fat, args[1])
        try:
            if fat.isdir(path):
                fat.removedir(path)       # must be empty, like f_unlink
            else:
                fat.remove(path)
        except (fserrors.FSError, PyFATException) as e:
            raise HdfError(fat_error("Deletion failed", e))
    finally:
        fat.close()


def cmd_rebuild(args, part):
    fmt, args = parse_fat_flags(args)
    if not 2 <= len(args) <= 3:
        raise HdfError("Usage: hdfmonkey rebuild [--fat12|--fat16|--fat32] "
                       "<source-image-file> <destination-image-file> "
                       "[volumelabel]")
    src_fat = open_fat(args[0], False, part)
    try:
        src_img = DiskImage(args[0])
        sectors = src_img.sector_count
        src_img.close()
        dst_img = DiskImage.create(args[1], sectors)
        try:
            make_filesystem(dst_img, fmt, args[2] if len(args) > 2 else None)
        finally:
            dst_img.close()
        dst_fat = open_fat(args[1], True)
        try:
            fat_copy_tree(src_fat, dst_fat)
        finally:
            dst_fat.close()
    finally:
        src_fat.close()


HELP = {
    "clone": ("Make a new image file from a disk or image, possibly in a "
              "different container format",
              "hdfmonkey clone <oldimagefile> <newimagefile>"),
    "create": ("Create a new FAT-formatted image file",
               "hdfmonkey create [--fat12|--fat16|--fat32] <imagefile> <size> "
               "[volumelabel]\nSize is given in bytes (B), kilobytes (K), "
               "megabytes (M) or gigabytes (G) -\ne.g. 64M, 1.5G"),
    "format": ("Formats the entire disk image as a FAT filesystem",
               "hdfmonkey format [--fat12|--fat16|--fat32] <imagefile> "
               "[volumelabel]"),
    "get": ("Copy a file from the disk image to a local file",
            "hdfmonkey get <imagefile> <sourcefile> [destfile]\nWill write the "
            "file to standard output if no destination file is specified."),
    "help": ("Describe the usage of this program or its commands.",
             "hdfmonkey help [command]"),
    "ls": ("Show a directory listing",
           "hdfmonkey ls <imagefile> [path]\nWill list the root directory if "
           "no path is specified."),
    "mkdir": ("Create a directory", "hdfmonkey mkdir <imagefile> <dirname>"),
    "put": ("Copy local files to the disk image",
            "hdfmonkey put <image-file> <source-files> <dest-file-or-dir>"),
    "rebuild": ("Copy contents of the source image file-by-file to a new disk "
                "image;\n\tensures that the resulting image is unfragmented.",
                "hdfmonkey rebuild [--fat12|--fat16|--fat32] "
                "<source-image-file> <destination-image-file> [volumelabel]"),
    "rm": ("Remove a file or directory",
           "hdfmonkey rm <imagefile> <filename>\nDirectories must be empty "
           "before they can be deleted."),
}

COMMANDS = {
    "clone": cmd_clone, "create": cmd_create, "format": cmd_format,
    "get": cmd_get, "ls": cmd_ls, "mkdir": cmd_mkdir, "put": cmd_put,
    "rebuild": cmd_rebuild, "rm": cmd_rm,
}


def cmd_help(args, part=0):
    if not args:
        print("hdfmonkey: utility for manipulating HDF disk images\n")
        print("usage: hdfmonkey <command> [args]\n")
        print("Type 'hdfmonkey help <command>' for help on a specific command.")
        print("Available commands:")
        for name in sorted(HELP):
            print("\t" + name)
    elif args[0] in HELP:
        desc, usage = HELP[args[0]]
        print("%s: %s" % (args[0], desc))
        print("usage: " + usage)
    else:
        print("Unknown command: '%s'" % args[0])
    return 0


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):  # Windows consoles: never crash on odd names
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    argv = list(sys.argv[1:] if argv is None else argv)
    part = 0
    while argv and argv[0] in ("-p", "--partition"):
        try:
            part = int(argv[1])
            if not 0 <= part <= 3:
                raise ValueError
        except (IndexError, ValueError):
            print("Partition must be a number from 0 to 3")
            return 1
        argv = argv[2:]
    if not argv:
        return cmd_help([]) or 0
    command, args = argv[0], argv[1:]
    if command == "help":
        return cmd_help(args)
    if command not in COMMANDS:
        print("Unknown command: '%s'" % command)
        print("Type 'hdfmonkey help' for usage.")
        return 1
    try:
        return COMMANDS[command](args, part) or 0
    except HdfError as e:
        print(e)
        return 1
    except BrokenPipeError:
        return 0


if __name__ == "__main__":
    sys.exit(main())
